<div class="row" style="margin-top: 15px;">
    <div class="col-md-10 col-md-offset-1" id="apiOutput" style="display: none;">
        ...
    </div>
</div>